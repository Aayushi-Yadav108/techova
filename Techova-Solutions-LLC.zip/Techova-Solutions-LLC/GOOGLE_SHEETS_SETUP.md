# Google Sheets Integration Setup Guide

This guide will help you set up the contact form to save submissions to Google Sheets.

## Step 1: Create a Google Sheet

1. Go to [Google Sheets](https://sheets.google.com)
2. Create a new blank spreadsheet
3. Name it "Techova Contact Form Submissions" (or any name you prefer)
4. Copy the Sheet ID from the URL:
   - The URL will look like: `https://docs.google.com/spreadsheets/d/SHEET_ID_HERE/edit`
   - Copy the `SHEET_ID_HERE` part

## Step 2: Create Google Apps Script

1. Go to [Google Apps Script](https://script.google.com)
2. Click "New Project"
3. Delete the default code
4. Open the file `google-apps-script.js` from this project
5. Copy all the code and paste it into the Google Apps Script editor
6. Replace `'YOUR_SHEET_ID_HERE'` on line 15 with your actual Sheet ID
7. Click "Save" (or press Ctrl+S / Cmd+S)
8. Name your project (e.g., "Techova Contact Form")

## Step 3: Deploy as Web App

1. In Google Apps Script, click "Deploy" > "New deployment"
2. Click the gear icon (⚙️) next to "Select type"
3. Choose "Web app"
4. Configure the deployment:
   - **Description**: "Techova Contact Form Handler" (optional)
   - **Execute as**: "Me" (your email)
   - **Who has access**: "Anyone" (important for public website)
5. Click "Deploy"
6. **IMPORTANT**: Authorize the script when prompted:
   - Click "Authorize access"
   - Choose your Google account
   - Click "Advanced" > "Go to [Project Name] (unsafe)"
   - Click "Allow"
7. Copy the **Web App URL** (it will look like: `https://script.google.com/macros/s/...`)

## Step 4: Update Your Website

1. Open `js/script.js` in your project
2. Find line 119: `const scriptURL = 'YOUR_GOOGLE_APPS_SCRIPT_URL_HERE';`
3. Replace `'YOUR_GOOGLE_APPS_SCRIPT_URL_HERE'` with your Web App URL (from Step 3)
4. Save the file

## Step 5: Test the Form

1. Open your website in a browser
2. Fill out the contact form
3. Submit the form
4. Check your Google Sheet - you should see the data appear in a new row

## Troubleshooting

### Form shows warning message
- Make sure you've updated the `scriptURL` in `js/script.js`
- Verify the URL is correct (no extra spaces or quotes)

### Data not appearing in Google Sheet
- Check that the Sheet ID in Google Apps Script is correct
- Make sure the sheet name matches "Contact Form Submissions" (or update it in the script)
- Verify the deployment has "Anyone" access
- Check the Google Apps Script execution log for errors

### CORS errors in browser console
- This is normal with `no-cors` mode - the data is still being sent
- The form will show a success message even if you can't read the response

### Need to update the script
- After making changes to Google Apps Script, you need to create a new deployment
- Go to Deploy > Manage deployments > Edit (pencil icon) > New version > Deploy

## Security Notes

- The Web App URL is public, but only authorized to write to your specific Google Sheet
- Consider adding rate limiting or CAPTCHA for production use
- Regularly monitor your Google Sheet for spam submissions

## Support

If you encounter issues:
1. Check the Google Apps Script execution log (View > Executions)
2. Verify all URLs and IDs are correct
3. Test the script using the `test()` function in Google Apps Script

