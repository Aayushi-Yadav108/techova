/**
 * Google Apps Script for Techova Solutions Contact Form
 * 
 * INSTRUCTIONS:
 * 1. Go to https://script.google.com
 * 2. Create a new project
 * 3. Copy and paste this entire code
 * 4. Create a new Google Sheet and copy its ID from the URL
 * 5. Replace 'YOUR_SHEET_ID_HERE' with your actual Google Sheet ID
 * 6. Save the script
 * 7. Deploy > New deployment > Web app
 * 8. Set "Execute as" to "Me"
 * 9. Set "Who has access" to "Anyone"
 * 10. Click Deploy and copy the Web App URL
 * 11. Update the scriptURL in js/script.js with this URL
 */

// Replace this with your Google Sheet ID (found in the sheet URL)
const SHEET_ID = 'YOUR_SHEET_ID_HERE';
const SHEET_NAME = 'Contact Form Submissions';

/**
 * Handle POST request from contact form
 */
function doPost(e) {
  try {
    // Parse the JSON data
    const data = JSON.parse(e.postData.contents);
    
    // Open the Google Sheet
    const sheet = SpreadsheetApp.openById(SHEET_ID).getSheetByName(SHEET_NAME);
    
    // If sheet doesn't exist, create it with headers
    if (!sheet) {
      const newSheet = SpreadsheetApp.openById(SHEET_ID).insertSheet(SHEET_NAME);
      newSheet.appendRow(['Timestamp', 'Name', 'Email', 'Phone', 'Subject', 'Message']);
      newSheet.getRange(1, 1, 1, 6).setFontWeight('bold');
      newSheet.getRange(1, 1, 1, 6).setBackground('#0066cc');
      newSheet.getRange(1, 1, 1, 6).setFontColor('#ffffff');
    }
    
    // Get the sheet (create if it was just created)
    const targetSheet = SpreadsheetApp.openById(SHEET_ID).getSheetByName(SHEET_NAME);
    
    // Append the form data to the sheet
    targetSheet.appendRow([
      data.timestamp || new Date().toISOString(),
      data.name || '',
      data.email || '',
      data.phone || '',
      data.subject || '',
      data.message || ''
    ]);
    
    // Return success response
    return ContentService
      .createTextOutput(JSON.stringify({
        'status': 'success',
        'message': 'Form submitted successfully'
      }))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    // Return error response
    return ContentService
      .createTextOutput(JSON.stringify({
        'status': 'error',
        'message': error.toString()
      }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Handle GET request (for testing)
 */
function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({
      'status': 'success',
      'message': 'Techova Solutions Contact Form API is running'
    }))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * Test function to verify the script works
 */
function test() {
  const testData = {
    timestamp: new Date().toISOString(),
    name: 'Test User',
    email: 'test@example.com',
    phone: '1234567890',
    subject: 'Test Subject',
    message: 'This is a test message'
  };
  
  const mockEvent = {
    postData: {
      contents: JSON.stringify(testData)
    }
  };
  
  const result = doPost(mockEvent);
  Logger.log(result.getContent());
}

