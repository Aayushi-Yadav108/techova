// ============================================
// Smooth Scrolling
// ============================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            const offsetTop = target.offsetTop - 200; // Account for fixed navbar and top header
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// ============================================
// Navbar Scroll Effect
// ============================================
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.background = 'linear-gradient(135deg, rgba(30, 58, 138, 0.98) 0%, rgba(30, 64, 175, 0.98) 100%)';
        navbar.style.backdropFilter = 'blur(10px)';
        navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.2)';
    } else {
        navbar.style.background = 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%)';
        navbar.style.backdropFilter = 'none';
        navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15)';
    }
});

// ============================================
// Active Navigation Link
// ============================================
window.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-left .nav-link, .nav-right .nav-link, .mobile-nav .nav-link');
    
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (window.scrollY >= sectionTop - 110) {
            current = section.getAttribute('id');
        }
    });

    navLinks.forEach(link => {
        // Skip dropdown toggle links
        if (link.classList.contains('dropdown-toggle')) return;
        
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// ============================================
// Animated Counter for Stats
// ============================================
function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    
    const timer = setInterval(() => {
        start += increment;
        if (start >= target) {
            element.textContent = target + '+';
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(start) + '+';
        }
    }, 16);
}

// Intersection Observer for Stats Animation
const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const statNumber = entry.target;
            const target = parseInt(statNumber.getAttribute('data-target'));
            animateCounter(statNumber, target);
            statsObserver.unobserve(statNumber);
        }
    });
}, { threshold: 0.5 });

document.querySelectorAll('.stat-number').forEach(stat => {
    statsObserver.observe(stat);
});

// ============================================
// Contact Form Handling
// ============================================
const contactForm = document.getElementById('contactForm');
const formMessage = document.getElementById('formMessage');

if (contactForm) {
    contactForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            subject: document.getElementById('subject').value,
            message: document.getElementById('message').value,
            timestamp: new Date().toISOString()
        };

        // Show loading state
        const submitButton = contactForm.querySelector('button[type="submit"]');
        const originalButtonText = submitButton.innerHTML;
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Sending...';

        try {
            // Google Apps Script Web App URL
            // Replace this with your actual Google Apps Script deployment URL
            // Get it from: Deploy > Manage deployments > Copy the Web App URL
            const scriptURL = 'YOUR_GOOGLE_APPS_SCRIPT_URL_HERE';
            
            // Check if URL is configured
            if (scriptURL && scriptURL !== 'YOUR_GOOGLE_APPS_SCRIPT_URL_HERE') {
                // Send data to Google Apps Script
                const response = await fetch(scriptURL, {
                    method: 'POST',
                    mode: 'no-cors', // Required for Google Apps Script
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(formData)
                });
                
                // Note: With 'no-cors' mode, we can't read the response
                // But the data will still be sent to Google Sheets
                // Show success message
                formMessage.className = 'alert alert-success mt-3';
                formMessage.style.display = 'block';
                formMessage.innerHTML = '<i class="bi bi-check-circle-fill me-2"></i>Thanks for contacting Techova support, we will be in touch with you shortly!';
                
                // Reset form
                contactForm.reset();
                
                // Hide message after 5 seconds
                setTimeout(() => {
                    formMessage.style.display = 'none';
                }, 5000);
            } else {
                // Fallback: Show success message even if URL not configured
                // (for testing purposes - data won't be saved)
                console.warn('Google Apps Script URL not configured. Form data:', formData);
                
                formMessage.className = 'alert alert-warning mt-3';
                formMessage.style.display = 'block';
                formMessage.innerHTML = '<i class="bi bi-exclamation-triangle-fill me-2"></i>Form submitted! (Note: Please configure Google Apps Script URL to save data to Google Sheets)';
                
                // Reset form
                contactForm.reset();
                
                // Hide message after 5 seconds
                setTimeout(() => {
                    formMessage.style.display = 'none';
                }, 5000);
            }
            
        } catch (error) {
            console.error('Error:', error);
            formMessage.className = 'alert alert-danger mt-3';
            formMessage.style.display = 'block';
            formMessage.innerHTML = '<i class="bi bi-exclamation-triangle-fill me-2"></i>Sorry, there was an error submitting your message. Please try again later.';
            
            setTimeout(() => {
                formMessage.style.display = 'none';
            }, 5000);
        } finally {
            // Reset button state
            submitButton.disabled = false;
            submitButton.innerHTML = originalButtonText;
        }
    });
}

// ============================================
// Fade In Animation on Scroll
// ============================================
const fadeElements = document.querySelectorAll('.service-card, .about-features li, .database-badge');

const fadeObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
        if (entry.isIntersecting) {
            setTimeout(() => {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }, index * 100);
            fadeObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.1 });

fadeElements.forEach(element => {
    element.style.opacity = '0';
    element.style.transform = 'translateY(20px)';
    element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    fadeObserver.observe(element);
});

// ============================================
// Mobile Menu Close on Link Click
// ============================================
document.querySelectorAll('.mobile-nav .nav-link').forEach(link => {
    link.addEventListener('click', () => {
        const navbarCollapse = document.querySelector('#mobileNav');
        if (navbarCollapse.classList.contains('show')) {
            const bsCollapse = new bootstrap.Collapse(navbarCollapse, {
                toggle: false
            });
            bsCollapse.hide();
        }
    });
});

// ============================================
// Mega Menu Hover Effect
// ============================================
const servicesDropdown = document.getElementById('servicesDropdown');
const megaMenu = document.querySelector('.mega-menu');

if (servicesDropdown && megaMenu) {
    let hoverTimeout;
    
    servicesDropdown.addEventListener('mouseenter', () => {
        clearTimeout(hoverTimeout);
        const dropdown = new bootstrap.Dropdown(servicesDropdown);
        dropdown.show();
    });
    
    megaMenu.addEventListener('mouseleave', () => {
        hoverTimeout = setTimeout(() => {
            const dropdown = bootstrap.Dropdown.getInstance(servicesDropdown);
            if (dropdown) {
                dropdown.hide();
            }
        }, 200);
    });
    
    megaMenu.addEventListener('mouseenter', () => {
        clearTimeout(hoverTimeout);
    });
}

// ============================================
// Hero Carousel Auto-Slide
// ============================================
let currentSlide = 0;
const slides = document.querySelectorAll('.hero-slide');
const indicators = document.querySelectorAll('.carousel-indicator');
const totalSlides = slides.length;

function showSlide(index) {
    // Remove active class from all slides and indicators
    slides.forEach(slide => slide.classList.remove('active'));
    indicators.forEach(indicator => indicator.classList.remove('active'));
    
    // Add active class to current slide and indicator
    if (slides[index]) {
        slides[index].classList.add('active');
    }
    if (indicators[index]) {
        indicators[index].classList.add('active');
    }
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % totalSlides;
    showSlide(currentSlide);
}

// Auto-advance carousel every 5 seconds
let carouselInterval = setInterval(nextSlide, 5000);

// Pause on hover
const heroCarousel = document.querySelector('.hero-carousel');
if (heroCarousel) {
    heroCarousel.addEventListener('mouseenter', () => {
        clearInterval(carouselInterval);
    });
    
    heroCarousel.addEventListener('mouseleave', () => {
        carouselInterval = setInterval(nextSlide, 5000);
    });
}

// Manual indicator click
indicators.forEach((indicator, index) => {
    indicator.addEventListener('click', () => {
        currentSlide = index;
        showSlide(currentSlide);
        // Reset auto-advance timer
        clearInterval(carouselInterval);
        carouselInterval = setInterval(nextSlide, 5000);
    });
});

// Initialize first slide
if (slides.length > 0) {
    showSlide(0);
}

// ============================================
// Console Welcome Message
// ============================================
console.log('%cWelcome to Techova Solutions!', 'color: #0066cc; font-size: 20px; font-weight: bold;');
console.log('%cWe provide cloud computing and database solutions.', 'color: #666; font-size: 14px;');

